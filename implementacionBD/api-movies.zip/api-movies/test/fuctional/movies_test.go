package tests

import (
	"api-movies/cmd/server/handler"
	"api-movies/internal/domain"
	"api-movies/internal/movie"
	"api-movies/pkg/db"
	"bytes"
	"encoding/json"
	"log"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
	"github.com/stretchr/testify/require"
	"gopkg.in/go-playground/assert.v1"
)

var s = createServer()

func createServer() *gin.Engine {
	err := godotenv.Load()
	if err != nil {
		log.Fatal("Error: Loading .env")
	}

	_, db := db.ConnectDatabase()
	repo := movie.NewRepository(db)
	serv := movie.NewService(repo)

	movie := handler.NewMovie(serv)

	gin.SetMode(gin.ReleaseMode)
	r := gin.Default()
	pr := r.Group("/api/v1/movies")
	pr.GET("/", movie.GetByTitle())
	pr.POST("/", movie.Store())

	return r
}

func createRequest(method, url, body string) (*http.Request, *httptest.ResponseRecorder) {
	req := httptest.NewRequest(method, url, bytes.NewBuffer([]byte(body)))
	req.Header.Set("Content-Type", "application/json")

	return req, httptest.NewRecorder()
}

func TestStoreMovie_Ok(t *testing.T) {
	new := domain.Movie{
		Title:  "Lapeli",
		Rating: 9,
		Awards: 3,
	}

	movie, err := json.Marshal(new)
	require.Nil(t, err)

	request, response := createRequest(http.MethodPost, "/api/v1/movies/", string(movie))
	s.ServeHTTP(response, request)

	assert.Equal(t, http.StatusCreated, response.Code)

	m := struct{ Data domain.Movie }{}
	err = json.Unmarshal(response.Body.Bytes(), &m)
	require.Nil(t, err)

	new.ID = m.Data.ID
	assert.Equal(t, new, m.Data)
}

func TestGetByTitle_Ok(t *testing.T) {
	request, response := createRequest(http.MethodGet, "/api/v1/movies/", `{"title":"Lapeli"}`)
	s.ServeHTTP(response, request)

	assert.Equal(t, http.StatusOK, response.Code)
}
